<!doctype html >
<!--[if IE 8]>    <html class="ie8" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en-US" prefix="og: http://ogp.me/ns#"> <!--<![endif]-->
<head><link rel="stylesheet" type="text/css" href="http://www.promasti.com/wp-content/cache/minify/7dd8f.css" media="all" />

	
  <meta charset="UTF-8">
  <meta name="description" content="ProMasti.Com Is a Blog known for Sharing knowledge about on Android, Internet, YouTube, Blogger, Make money, How to and Technical tips and tricks tutorial">
  <meta name="keywords" content=" internet tips, how to, hindi, tips and tricks, make money, youtube, blogger, wordpress, technical, android, apps, games, Whatsapp">
  <meta name="author" content="RipoN">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-109049948-4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-109049948-4');
</script>

	
    <title>Page not found - PROMasti.Com</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="pingback" href="http://www.promasti.com/xmlrpc.php" />
    <link rel="icon" type="image/png" href="http://promasti.com/wp-content/uploads/2017/12/layers-pro-logo-invert.png">
<!-- This site is optimized with the Yoast SEO Premium plugin v5.6 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - PROMasti.Com" />
<meta property="og:site_name" content="PROMasti.Com" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Page not found - PROMasti.Com" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"http:\/\/www.promasti.com\/","name":"PROMasti.Com","potentialAction":{"@type":"SearchAction","target":"http:\/\/www.promasti.com\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<!-- / Yoast SEO Premium plugin. -->

<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="PROMasti.Com &raquo; Feed" href="http://www.promasti.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="PROMasti.Com &raquo; Comments Feed" href="http://www.promasti.com/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v7.0.9 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
	var mi_track_user      = true;
	var mi_no_track_reason = '';
	
	var disableStr = 'ga-disable-UA-109049948-4';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
	
	if ( mi_track_user ) {
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

		__gaTracker('create', 'UA-109049948-4', 'auto');
		__gaTracker('set', 'forceSSL', true);
		__gaTracker('require', 'displayfeatures');
		__gaTracker('require', 'linkid', 'linkid.js');
		__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
	} else {
		console.log( "" );
		(function() {
			/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
			var noopfn = function() {
				return null;
			};
			var noopnullfn = function() {
				return null;
			};
			var Tracker = function() {
				return null;
			};
			var p = Tracker.prototype;
			p.get = noopfn;
			p.set = noopfn;
			p.send = noopfn;
			var __gaTracker = function() {
				var len = arguments.length;
				if ( len === 0 ) {
					return;
				}
				var f = arguments[len-1];
				if ( typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function' ) {
					console.log( 'Not running function __gaTracker(' + arguments[0] + " ....) because you are not being tracked. " + mi_no_track_reason );
					return;
				}
				try {
					f.hitCallback();
				} catch (ex) {

				}
			};
			__gaTracker.create = function() {
				return new Tracker();
			};
			__gaTracker.getByName = noopnullfn;
			__gaTracker.getAll = function() {
				return [];
			};
			__gaTracker.remove = noopfn;
			window['__gaTracker'] = __gaTracker;
					})();
		}
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.promasti.com\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		






<link rel='stylesheet' id='google-fonts-style-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400%2C400italic%2C600%2C600italic%2C700%7CRoboto%3A300%2C400%2C400italic%2C500%2C500italic%2C700%2C900' type='text/css' media='all' />






<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"http:\/\/www.promasti.com","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type="text/javascript" src="http://www.promasti.com/wp-content/cache/minify/92205.js"></script>



<link rel='https://api.w.org/' href='http://www.promasti.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.promasti.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.promasti.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.7" />
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-4378253064019460",
          enable_page_level_ads: true
     });
</script><!--[if IE 7]>
<link rel="stylesheet" href="http://www.promasti.com/wp-content/plugins/wp-review/assets/css/wp-review-ie7.css">
<![endif]-->

<link rel='dns-prefetch' href='//v0.wordpress.com'/>
				<script>
				window.tdwGlobal = {"adminUrl":"http:\/\/www.promasti.com\/wp-admin\/","wpRestNonce":"4f1331e4a0","wpRestUrl":"http:\/\/www.promasti.com\/wp-json\/","permalinkStructure":"\/%postname%\/"};
			</script>
			<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    
<!-- JS generated by theme -->

<script>
    
    

	    var tdBlocksArray = []; //here we store all the items for the current page

	    //td_block class - each ajax block uses a object of this class for requests
	    function tdBlock() {
		    this.id = '';
		    this.block_type = 1; //block type id (1-234 etc)
		    this.atts = '';
		    this.td_column_number = '';
		    this.td_current_page = 1; //
		    this.post_count = 0; //from wp
		    this.found_posts = 0; //from wp
		    this.max_num_pages = 0; //from wp
		    this.td_filter_value = ''; //current live filter value
		    this.is_ajax_running = false;
		    this.td_user_action = ''; // load more or infinite loader (used by the animation)
		    this.header_color = '';
		    this.ajax_pagination_infinite_stop = ''; //show load more at page x
	    }


        // td_js_generator - mini detector
        (function(){
            var htmlTag = document.getElementsByTagName("html")[0];

            if ( navigator.userAgent.indexOf("MSIE 10.0") > -1 ) {
                htmlTag.className += ' ie10';
            }

            if ( !!navigator.userAgent.match(/Trident.*rv\:11\./) ) {
                htmlTag.className += ' ie11';
            }

            if ( /(iPad|iPhone|iPod)/g.test(navigator.userAgent) ) {
                htmlTag.className += ' td-md-is-ios';
            }

            var user_agent = navigator.userAgent.toLowerCase();
            if ( user_agent.indexOf("android") > -1 ) {
                htmlTag.className += ' td-md-is-android';
            }

            if ( -1 !== navigator.userAgent.indexOf('Mac OS X')  ) {
                htmlTag.className += ' td-md-is-os-x';
            }

            if ( /chrom(e|ium)/.test(navigator.userAgent.toLowerCase()) ) {
               htmlTag.className += ' td-md-is-chrome';
            }

            if ( -1 !== navigator.userAgent.indexOf('Firefox') ) {
                htmlTag.className += ' td-md-is-firefox';
            }

            if ( -1 !== navigator.userAgent.indexOf('Safari') && -1 === navigator.userAgent.indexOf('Chrome') ) {
                htmlTag.className += ' td-md-is-safari';
            }

            if( -1 !== navigator.userAgent.indexOf('IEMobile') ){
                htmlTag.className += ' td-md-is-iemobile';
            }

        })();




        var tdLocalCache = {};

        ( function () {
            "use strict";

            tdLocalCache = {
                data: {},
                remove: function (resource_id) {
                    delete tdLocalCache.data[resource_id];
                },
                exist: function (resource_id) {
                    return tdLocalCache.data.hasOwnProperty(resource_id) && tdLocalCache.data[resource_id] !== null;
                },
                get: function (resource_id) {
                    return tdLocalCache.data[resource_id];
                },
                set: function (resource_id, cachedData) {
                    tdLocalCache.remove(resource_id);
                    tdLocalCache.data[resource_id] = cachedData;
                }
            };
        })();

    
    
var td_viewport_interval_list=[{"limitBottom":767,"sidebarWidth":228},{"limitBottom":1018,"sidebarWidth":300},{"limitBottom":1140,"sidebarWidth":324}];
var td_animation_stack_effect="type0";
var tds_animation_stack=true;
var td_animation_stack_specific_selectors=".entry-thumb, img";
var td_animation_stack_general_selectors=".td-animation-stack img, .td-animation-stack .entry-thumb, .post img";
var td_ajax_url="http:\/\/www.promasti.com\/wp-admin\/admin-ajax.php?td_theme_name=Newspaper&v=8.1";
var td_get_template_directory_uri="http:\/\/www.promasti.com\/wp-content\/themes\/Newspaper";
var tds_snap_menu="";
var tds_logo_on_sticky="";
var tds_header_style="3";
var td_please_wait="Please wait...";
var td_email_user_pass_incorrect="User or password incorrect!";
var td_email_user_incorrect="Email or username incorrect!";
var td_email_incorrect="Email incorrect!";
var tds_more_articles_on_post_enable="show";
var tds_more_articles_on_post_time_to_wait="";
var tds_more_articles_on_post_pages_distance_from_top=0;
var tds_theme_color_site_wide="#4db2ec";
var tds_smart_sidebar="";
var tdThemeName="Newspaper";
var td_magnific_popup_translation_tPrev="Previous (Left arrow key)";
var td_magnific_popup_translation_tNext="Next (Right arrow key)";
var td_magnific_popup_translation_tCounter="%curr% of %total%";
var td_magnific_popup_translation_ajax_tError="The content from %url% could not be loaded.";
var td_magnific_popup_translation_image_tError="The image #%curr% could not be loaded.";
var tdsDateFormat="l, F j, Y";
var tdDateNamesI18n={"month_names":["January","February","March","April","May","June","July","August","September","October","November","December"],"month_names_short":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"day_names":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"day_names_short":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]};
var td_ad_background_click_link="";
var td_ad_background_click_target="";
</script>


<!-- Header style compiled by theme -->



<link rel="icon" href="http://www.promasti.com/wp-content/uploads/2017/12/cropped-ProMasti-Fav-icon-e1513220589293-32x32.png" sizes="32x32" />
<link rel="icon" href="http://www.promasti.com/wp-content/uploads/2017/12/cropped-ProMasti-Fav-icon-e1513220589293-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://www.promasti.com/wp-content/uploads/2017/12/cropped-ProMasti-Fav-icon-e1513220589293-180x180.png" />
<meta name="msapplication-TileImage" content="http://www.promasti.com/wp-content/uploads/2017/12/cropped-ProMasti-Fav-icon-e1513220589293-270x270.png" />
</head>

<body class="error404 global-block-template-1 td-animation-stack-type0 td-boxed-layout" itemscope="itemscope" itemtype="http://schema.org/WebPage">

        <div class="td-scroll-up"><i class="td-icon-menu-up"></i></div>
    
    <div class="td-menu-background"></div>
<div id="td-mobile-nav">
    <div class="td-mobile-container">
        <!-- mobile menu top section -->
        <div class="td-menu-socials-wrap">
            <!-- socials -->
            <div class="td-menu-socials">
                            </div>
            <!-- close button -->
            <div class="td-mobile-close">
                <a href="#"><i class="td-icon-close-mobile"></i></a>
            </div>
        </div>

        <!-- login section -->
        
        <!-- menu section -->
        <div class="td-mobile-content">
            <div class="menu-main-header-menu-container"><ul id="menu-main-header-menu" class="td-mobile-main-menu"><li id="menu-item-56" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-first menu-item-56"><a href="http://promasti.com/"><i class="_mi _before dashicons dashicons-admin-home" aria-hidden="true"></i><span>Home</span></a></li>
<li id="menu-item-481" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-481"><a href="http://www.promasti.com/category/whatsapp/"><i class="_mi _before dashicons dashicons-format-links" aria-hidden="true"></i><span>WhatsApp</span><i class="td-icon-menu-right td-element-after"></i></a>
<ul class="sub-menu">
	<li id="menu-item-148" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-148"><a href="http://www.promasti.com/category/whatsapp-groups-links/">WhatsApp Group Links</a></li>
	<li id="menu-item-480" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-480"><a href="http://www.promasti.com/category/whatsapp-status/">Whatsapp Status</a></li>
</ul>
</li>
<li id="menu-item-482" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-482"><a href="http://www.promasti.com/category/internet/"><i class="_mi _before dashicons dashicons-admin-site" aria-hidden="true"></i><span>Internet</span><i class="td-icon-menu-right td-element-after"></i></a>
<ul class="sub-menu">
	<li id="menu-item-479" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-479"><a href="http://www.promasti.com/category/make-money-online/">Make Money Online</a></li>
	<li id="menu-item-477" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-477"><a href="http://www.promasti.com/category/blogger/">Blogger</a></li>
</ul>
</li>
<li id="menu-item-483" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-483"><a href="http://www.promasti.com/category/news/"><i class="_mi _before dashicons dashicons-format-standard" aria-hidden="true"></i><span>News</span></a></li>
<li id="menu-item-487" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-487"><a href="http://www.promasti.com/category/android-apps/"><i class="_mi _before dashicons dashicons-smartphone" aria-hidden="true"></i><span>Android</span></a></li>
<li id="menu-item-537" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-537"><a href="http://www.promasti.com/about/"><i class="_mi _before dashicons dashicons-info" aria-hidden="true"></i><span>About</span></a></li>
</ul></div>        </div>
    </div>

    <!-- register/login section -->
    </div>    <div class="td-search-background"></div>
<div class="td-search-wrap-mob">
	<div class="td-drop-down-search" aria-labelledby="td-header-search-button">
		<form method="get" class="td-search-form" action="http://www.promasti.com/">
			<!-- close button -->
			<div class="td-search-close">
				<a href="#"><i class="td-icon-close-mobile"></i></a>
			</div>
			<div role="search" class="td-search-input">
				<span>Search</span>
				<input id="td-header-search-mob" type="text" value="" name="s" autocomplete="off" />
			</div>
		</form>
		<div id="td-aj-search-mob"></div>
	</div>
</div>    
    
    <div id="td-outer-wrap" class="td-theme-wrap">
    
        <!--
Header style 3
-->

<div class="td-header-wrap td-header-style-3">

    <div class="td-header-top-menu-full td-container-wrap ">
        <div class="td-container td-header-row td-header-top-menu">
            
    <div class="top-bar-style-1">
        
<div class="td-header-sp-top-menu">


	        <div class="td_data_time">
            <div style="visibility:hidden;">

                Tuesday, July 24, 2018
            </div>
        </div>
    <div class="menu-top-container"><ul id="menu-top-menu" class="top-header-menu"><li id="menu-item-539" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-first td-menu-item td-normal-menu menu-item-539"><a href="http://www.promasti.com/about/">About</a></li>
<li id="menu-item-190" class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-190"><a href="http://promasti.com/sitemap.xml">Sitemap</a></li>
<li id="menu-item-538" class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-538"><a href="http://www.promasti.com/contact/">Contact Us</a></li>
<li id="menu-item-55" class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-55"><a href="http://www.promasti.com/privacy-policy/">Privacy Policy</a></li>
</ul></div></div>
        <div class="td-header-sp-top-widget">
    </div>
    </div>

<!-- LOGIN MODAL -->
        </div>
    </div>

    <div class="td-banner-wrap-full td-container-wrap ">
        <div class="td-container td-header-row td-header-header">
            <div class="td-header-sp-logo">
                            <a class="td-main-logo" href="http://www.promasti.com/">
                <img src="http://promasti.com/wp-content/uploads/2017/12/PROMasti-logo.png" alt=""/>
                <span class="td-visual-hidden">PROMasti.Com</span>
            </a>
                    </div>
            <div class="td-header-sp-recs">
                <div class="td-header-rec-wrap">
    
</div>            </div>
        </div>
    </div>

    <div class="td-header-menu-wrap-full td-container-wrap ">
        <div class="td-header-menu-wrap">
            <div class="td-container td-header-row td-header-main-menu black-menu">
                <div id="td-header-menu" role="navigation">
    <div id="td-top-mobile-toggle"><a href="#"><i class="td-icon-font td-icon-mobile"></i></a></div>
    <div class="td-main-menu-logo td-logo-in-header">
        		<a class="td-mobile-logo td-sticky-disable" href="http://www.promasti.com/">
			<img src="http://promasti.com/wp-content/uploads/2017/12/PROMasti-logo.png" alt=""/>
		</a>
			<a class="td-header-logo td-sticky-disable" href="http://www.promasti.com/">
			<img src="http://promasti.com/wp-content/uploads/2017/12/PROMasti-logo.png" alt=""/>
		</a>
	    </div>
    <div class="menu-main-header-menu-container"><ul id="menu-main-header-menu-1" class="sf-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-first td-menu-item td-normal-menu menu-item-56"><a href="http://promasti.com/"><i class="_mi _before dashicons dashicons-admin-home" aria-hidden="true"></i><span>Home</span></a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children td-menu-item td-normal-menu menu-item-481"><a href="http://www.promasti.com/category/whatsapp/"><i class="_mi _before dashicons dashicons-format-links" aria-hidden="true"></i><span>WhatsApp</span></a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-148"><a href="http://www.promasti.com/category/whatsapp-groups-links/">WhatsApp Group Links</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-480"><a href="http://www.promasti.com/category/whatsapp-status/">Whatsapp Status</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children td-menu-item td-normal-menu menu-item-482"><a href="http://www.promasti.com/category/internet/"><i class="_mi _before dashicons dashicons-admin-site" aria-hidden="true"></i><span>Internet</span></a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-479"><a href="http://www.promasti.com/category/make-money-online/">Make Money Online</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-477"><a href="http://www.promasti.com/category/blogger/">Blogger</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-483"><a href="http://www.promasti.com/category/news/"><i class="_mi _before dashicons dashicons-format-standard" aria-hidden="true"></i><span>News</span></a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-487"><a href="http://www.promasti.com/category/android-apps/"><i class="_mi _before dashicons dashicons-smartphone" aria-hidden="true"></i><span>Android</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-537"><a href="http://www.promasti.com/about/"><i class="_mi _before dashicons dashicons-info" aria-hidden="true"></i><span>About</span></a></li>
</ul></div></div>


<div class="td-search-wrapper">
    <div id="td-top-search">
        <!-- Search -->
        <div class="header-search-wrap">
            <div class="dropdown header-search">
                <a id="td-header-search-button" href="#" role="button" class="dropdown-toggle " data-toggle="dropdown"><i class="td-icon-search"></i></a>
                <a id="td-header-search-button-mob" href="#" role="button" class="dropdown-toggle " data-toggle="dropdown"><i class="td-icon-search"></i></a>
            </div>
        </div>
    </div>
</div>

<div class="header-search-wrap">
	<div class="dropdown header-search">
		<div class="td-drop-down-search" aria-labelledby="td-header-search-button">
			<form method="get" class="td-search-form" action="http://www.promasti.com/">
				<div role="search" class="td-head-form-search-wrap">
					<input id="td-header-search" type="text" value="" name="s" autocomplete="off" /><input class="wpb_button wpb_btn-inverse btn" type="submit" id="td-header-search-top" value="Search" />
				</div>
			</form>
			<div id="td-aj-search"></div>
		</div>
	</div>
</div>            </div>
        </div>
    </div>

</div><div class="td-main-content-wrap td-container-wrap">
    <div class="td-container">
        <div class="td-pb-row">
            <div class="td-pb-span12">
                <div class="td-404-title">
                    Ooops... Error 404                </div>

                <div class="td-404-sub-title">
                    Sorry, but the page you are looking for doesn't exist.                </div>

                <div class="td-404-sub-sub-title">
                    You can go to the                    <a href="http://www.promasti.com/">HOMEPAGE</a>

                </div>


                <h4 class="block-title"><span>OUR LATEST POSTS</span></h4>

                

	<div class="td-block-row">

	<div class="td-block-span4">

        <div class="td_module_1 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="http://www.promasti.com/independence-day-wishing-script/" rel="bookmark" title="independence day Wishing Script | Whatsapp Sharing PRO Script"><img width="324" height="160" class="entry-thumb" src="http://www.promasti.com/wp-content/uploads/2018/07/wb2-324x160.jpg" srcset="http://www.promasti.com/wp-content/uploads/2018/07/wb2-324x160.jpg 324w, http://www.promasti.com/wp-content/uploads/2018/07/wb2-533x261.jpg 533w" sizes="(max-width: 324px) 100vw, 324px" alt="independence day Wishing Script" title="independence day Wishing Script | Whatsapp Sharing PRO Script"/></a></div>                            </div>
            <h3 class="entry-title td-module-title"><a href="http://www.promasti.com/independence-day-wishing-script/" rel="bookmark" title="independence day Wishing Script | Whatsapp Sharing PRO Script">independence day Wishing Script | Whatsapp Sharing PRO Script</a></h3>
            <div class="td-module-meta-info">
                <span class="td-post-author-name"><a href="http://www.promasti.com/author/admin/">RipoN</a> <span>-</span> </span>                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2018-07-20T20:53:40+00:00" >July 20, 2018</time></span>                <div class="td-module-comments"><a href="http://www.promasti.com/independence-day-wishing-script/#comments">22</a></div>            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_1 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="http://www.promasti.com/templates/" rel="bookmark" title="Top 5 Best Responsive Premium Blogger Templates"><img width="324" height="160" class="entry-thumb" src="http://www.promasti.com/wp-content/uploads/2018/07/Responsive-Premium-Blogger-Templates-324x160.jpg" srcset="http://www.promasti.com/wp-content/uploads/2018/07/Responsive-Premium-Blogger-Templates-324x160.jpg 324w, http://www.promasti.com/wp-content/uploads/2018/07/Responsive-Premium-Blogger-Templates-533x261.jpg 533w" sizes="(max-width: 324px) 100vw, 324px" alt="Top 5 Best Blogger Templates For Professional Blogs" title="Top 5 Best Responsive Premium Blogger Templates"/></a></div>                            </div>
            <h3 class="entry-title td-module-title"><a href="http://www.promasti.com/templates/" rel="bookmark" title="Top 5 Best Responsive Premium Blogger Templates">Top 5 Best Responsive Premium Blogger Templates</a></h3>
            <div class="td-module-meta-info">
                <span class="td-post-author-name"><a href="http://www.promasti.com/author/admin/">RipoN</a> <span>-</span> </span>                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2018-07-07T03:50:53+00:00" >July 7, 2018</time></span>                <div class="td-module-comments"><a href="http://www.promasti.com/templates/#comments">26</a></div>            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_1 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="http://www.promasti.com/best-group-buy-seo-tools/" rel="bookmark" title="Best Group buy SEO tools &#8211; Ahrefs, SemRush, Majestic, Moz, Grammarly all Tools in Rs.900/Month"><img width="324" height="160" class="entry-thumb" src="http://www.promasti.com/wp-content/uploads/2018/07/Group-Buy-SEO-Tools-324x160.png" srcset="http://www.promasti.com/wp-content/uploads/2018/07/Group-Buy-SEO-Tools-324x160.png 324w, http://www.promasti.com/wp-content/uploads/2018/07/Group-Buy-SEO-Tools-533x261.png 533w" sizes="(max-width: 324px) 100vw, 324px" alt="" title="Best Group buy SEO tools &#8211; Ahrefs, SemRush, Majestic, Moz, Grammarly all Tools in Rs.900/Month"/></a></div>                            </div>
            <h3 class="entry-title td-module-title"><a href="http://www.promasti.com/best-group-buy-seo-tools/" rel="bookmark" title="Best Group buy SEO tools &#8211; Ahrefs, SemRush, Majestic, Moz, Grammarly all Tools in Rs.900/Month">Best Group buy SEO tools &#8211; Ahrefs, SemRush, Majestic, Moz, Grammarly...</a></h3>
            <div class="td-module-meta-info">
                <span class="td-post-author-name"><a href="http://www.promasti.com/author/admin/">RipoN</a> <span>-</span> </span>                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2018-07-04T21:41:20+00:00" >July 4, 2018</time></span>                <div class="td-module-comments"><a href="http://www.promasti.com/best-group-buy-seo-tools/#comments">17</a></div>            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 --></div><!--./row-fluid-->

	<div class="td-block-row">

	<div class="td-block-span4">

        <div class="td_module_1 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="http://www.promasti.com/whatsapp-sharing-website-script/" rel="bookmark" title="12+ Free Whatsapp Sharing Website Script [Paytm Recharge, Modi Laptop, Spin and More..]"><img width="284" height="160" class="entry-thumb" src="http://www.promasti.com/wp-content/uploads/2018/05/12-Whatsapp-Viral-Script.jpg" srcset="http://www.promasti.com/wp-content/uploads/2018/05/12-Whatsapp-Viral-Script.jpg 672w, http://www.promasti.com/wp-content/uploads/2018/05/12-Whatsapp-Viral-Script-300x169.jpg 300w" sizes="(max-width: 284px) 100vw, 284px" alt="12+ Whatsapp Viral Script" title="12+ Free Whatsapp Sharing Website Script [Paytm Recharge, Modi Laptop, Spin and More..]"/></a></div>                            </div>
            <h3 class="entry-title td-module-title"><a href="http://www.promasti.com/whatsapp-sharing-website-script/" rel="bookmark" title="12+ Free Whatsapp Sharing Website Script [Paytm Recharge, Modi Laptop, Spin and More..]">12+ Free Whatsapp Sharing Website Script [Paytm Recharge, Modi Laptop, Spin...</a></h3>
            <div class="td-module-meta-info">
                <span class="td-post-author-name"><a href="http://www.promasti.com/author/admin/">RipoN</a> <span>-</span> </span>                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2018-05-19T09:26:09+00:00" >May 19, 2018</time></span>                <div class="td-module-comments"><a href="http://www.promasti.com/whatsapp-sharing-website-script/#comments">27</a></div>            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_1 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="http://www.promasti.com/seo-optimization-tips/" rel="bookmark" title="Advanced SEO Optimization Tips For BLOG/Website"><img width="284" height="160" class="entry-thumb" src="http://www.promasti.com/wp-content/uploads/2018/05/SEO-Optimization-Tips.jpg" srcset="http://www.promasti.com/wp-content/uploads/2018/05/SEO-Optimization-Tips.jpg 816w, http://www.promasti.com/wp-content/uploads/2018/05/SEO-Optimization-Tips-300x169.jpg 300w, http://www.promasti.com/wp-content/uploads/2018/05/SEO-Optimization-Tips-768x432.jpg 768w, http://www.promasti.com/wp-content/uploads/2018/05/SEO-Optimization-Tips-810x456.jpg 810w" sizes="(max-width: 284px) 100vw, 284px" alt="SEO Optimization Tips 2018" title="Advanced SEO Optimization Tips For BLOG/Website"/></a></div>                            </div>
            <h3 class="entry-title td-module-title"><a href="http://www.promasti.com/seo-optimization-tips/" rel="bookmark" title="Advanced SEO Optimization Tips For BLOG/Website">Advanced SEO Optimization Tips For BLOG/Website</a></h3>
            <div class="td-module-meta-info">
                <span class="td-post-author-name"><a href="http://www.promasti.com/author/admin/">RipoN</a> <span>-</span> </span>                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2018-05-12T06:04:07+00:00" >May 12, 2018</time></span>                <div class="td-module-comments"><a href="http://www.promasti.com/seo-optimization-tips/#comments">5</a></div>            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_1 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="http://www.promasti.com/root-android-phone/" rel="bookmark" title="Root Android Phone | Best rooting apps for android 2018"><img width="258" height="160" class="entry-thumb" src="http://www.promasti.com/wp-content/uploads/2018/05/Root-Android-Phone.jpg" srcset="http://www.promasti.com/wp-content/uploads/2018/05/Root-Android-Phone.jpg 998w, http://www.promasti.com/wp-content/uploads/2018/05/Root-Android-Phone-300x186.jpg 300w, http://www.promasti.com/wp-content/uploads/2018/05/Root-Android-Phone-768x476.jpg 768w, http://www.promasti.com/wp-content/uploads/2018/05/Root-Android-Phone-320x200.jpg 320w, http://www.promasti.com/wp-content/uploads/2018/05/Root-Android-Phone-810x502.jpg 810w" sizes="(max-width: 258px) 100vw, 258px" alt="Root Android Phone | Best rooting apps for android 2018" title="Root Android Phone | Best rooting apps for android 2018"/></a></div>                            </div>
            <h3 class="entry-title td-module-title"><a href="http://www.promasti.com/root-android-phone/" rel="bookmark" title="Root Android Phone | Best rooting apps for android 2018">Root Android Phone | Best rooting apps for android 2018</a></h3>
            <div class="td-module-meta-info">
                <span class="td-post-author-name"><a href="http://www.promasti.com/author/admin/">RipoN</a> <span>-</span> </span>                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2018-05-10T10:37:07+00:00" >May 10, 2018</time></span>                <div class="td-module-comments"><a href="http://www.promasti.com/root-android-phone/#comments">4</a></div>            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 --></div><!--./row-fluid-->            </div>
        </div> <!-- /.td-pb-row -->
    </div> <!-- /.td-container -->
</div> <!-- /.td-main-content-wrap -->


<!-- Instagram -->



<!-- Footer -->
<div class="td-footer-wrapper td-container-wrap ">
    <div class="td-container">

	    <div class="td-pb-row">
		    <div class="td-pb-span12">
                		    </div>
	    </div>

        <div class="td-pb-row">

            <div class="td-pb-span4">
                <aside class="td_block_template_1 widget jetpack_subscription_widget"><h4 class="block-title"><span>Subscribe to Blog via Email</span></h4>
			<form action="#" method="post" accept-charset="utf-8" id="subscribe-blog-blog_subscription-2">
				<div id="subscribe-text"><p>Enter your email address to subscribe to this blog and receive notifications of new posts by email.</p>
</div><p>Join 9 other subscribers</p>
					<p id="subscribe-email">
						<label id="jetpack-subscribe-label" for="subscribe-field-blog_subscription-2">
							Email Address						</label>
						<input type="email" name="email" required="required" class="required" value="" id="subscribe-field-blog_subscription-2" placeholder="Email Address" />
					</p>

					<p id="subscribe-submit">
						<input type="hidden" name="action" value="subscribe" />
						<input type="hidden" name="source" value="http://www.promasti.com/Pro%20Script/linkid.js" />
						<input type="hidden" name="sub-type" value="widget" />
						<input type="hidden" name="redirect_fragment" value="blog_subscription-2" />
												<input type="submit" value="Subscribe" name="jetpack_subscriptions_widget" />
					</p>
							</form>

			<script>
			/*
			Custom functionality for safari and IE
			 */
			(function( d ) {
				// In case the placeholder functionality is available we remove labels
				if ( ( 'placeholder' in d.createElement( 'input' ) ) ) {
					var label = d.querySelector( 'label[for=subscribe-field-blog_subscription-2]' );
						label.style.clip 	 = 'rect(1px, 1px, 1px, 1px)';
						label.style.position = 'absolute';
						label.style.height   = '1px';
						label.style.width    = '1px';
						label.style.overflow = 'hidden';
				}

				// Make sure the email value is filled in before allowing submit
				var form = d.getElementById('subscribe-blog-blog_subscription-2'),
					input = d.getElementById('subscribe-field-blog_subscription-2'),
					handler = function( event ) {
						if ( '' === input.value ) {
							input.focus();

							if ( event.preventDefault ){
								event.preventDefault();
							}

							return false;
						}
					};

				if ( window.addEventListener ) {
					form.addEventListener( 'submit', handler, false );
				} else {
					form.attachEvent( 'onsubmit', handler );
				}
			})( document );
			</script>
				
</aside>            </div>

            <div class="td-pb-span4">
                <aside class="td_block_template_1 widget widget_top-posts"><h4 class="block-title"><span>Top Posts &amp; Pages</span></h4><ul class='widgets-list-layout no-grav'>
					<li>
												<a href="http://www.promasti.com/whatsapp-adult-group-link/" title="Whatsapp 18+ Adult Group link join 2018 [*Updated*]" class="bump-view" data-bump-view="tp">
							<img width="40" height="40" src="https://i2.wp.com/www.promasti.com/wp-content/uploads/2017/12/Whatsapp-18-Group-link-join-2018.png?resize=40%2C40" class='widgets-list-layout-blavatar' alt="Whatsapp 18+ Adult Group link join 2018 [*Updated*]" data-pin-nopin="true" />
						</a>
						<div class="widgets-list-layout-links">
							<a href="http://www.promasti.com/whatsapp-adult-group-link/" class="bump-view" data-bump-view="tp">
								Whatsapp 18+ Adult Group link join 2018 [*Updated*]							</a>
						</div>
											</li>
									<li>
												<a href="http://www.promasti.com/whatsapp-group-links-2018/" title="(*Update*) Latest All Type of WhatsApp Group Link Collection 2018" class="bump-view" data-bump-view="tp">
							<img width="40" height="40" src="https://i1.wp.com/www.promasti.com/wp-content/uploads/2017/12/whatsapp-1.jpg?resize=40%2C40" class='widgets-list-layout-blavatar' alt="(*Update*) Latest All Type of WhatsApp Group Link Collection 2018" data-pin-nopin="true" />
						</a>
						<div class="widgets-list-layout-links">
							<a href="http://www.promasti.com/whatsapp-group-links-2018/" class="bump-view" data-bump-view="tp">
								(*Update*) Latest All Type of WhatsApp Group Link Collection 2018							</a>
						</div>
											</li>
									<li>
												<a href="http://www.promasti.com/adult-whatsapp-group-links/" title="{*LATEST*} FRESH ADULT WHATSAPP GROUP LINKS OF 2018" class="bump-view" data-bump-view="tp">
							<img width="40" height="40" src="https://i1.wp.com/www.promasti.com/wp-content/uploads/2017/12/18-Adult-Group-1.jpg?resize=40%2C40" class='widgets-list-layout-blavatar' alt="{*LATEST*} FRESH ADULT WHATSAPP GROUP LINKS OF 2018" data-pin-nopin="true" />
						</a>
						<div class="widgets-list-layout-links">
							<a href="http://www.promasti.com/adult-whatsapp-group-links/" class="bump-view" data-bump-view="tp">
								{*LATEST*} FRESH ADULT WHATSAPP GROUP LINKS OF 2018							</a>
						</div>
											</li>
				</ul>
</aside>            </div>

            <div class="td-pb-span4">
                <aside class="td_block_template_1 widget widget_archive"><h4 class="block-title"><span>Archives</span></h4>		<label class="screen-reader-text" for="archives-dropdown-3">Archives</label>
		<select id="archives-dropdown-3" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'>
			
			<option value="">Select Month</option>
				<option value='http://www.promasti.com/2018/07/'> July 2018 &nbsp;(3)</option>
	<option value='http://www.promasti.com/2018/05/'> May 2018 &nbsp;(5)</option>
	<option value='http://www.promasti.com/2018/04/'> April 2018 &nbsp;(4)</option>
	<option value='http://www.promasti.com/2018/03/'> March 2018 &nbsp;(5)</option>
	<option value='http://www.promasti.com/2018/02/'> February 2018 &nbsp;(2)</option>
	<option value='http://www.promasti.com/2018/01/'> January 2018 &nbsp;(10)</option>
	<option value='http://www.promasti.com/2017/12/'> December 2017 &nbsp;(13)</option>

		</select>
		</aside>            </div>
        </div>
    </div>
<div class="td-footer-bottom-full">
    <div class="td-container">
        <div class="td-pb-row">
            <div class="td-pb-span3"><aside class="footer-logo-wrap"><a href="http://www.promasti.com/"><img src="http://promasti.com/wp-content/uploads/2017/12/PROMasti-logo.png" alt="" title=""/></a></aside></div><div class="td-pb-span9"><aside class="footer-text-wrap"><div class="block-title"><span>ABOUT US</span></div>ProMasti.Com Is a Blog known for Sharing knowledge about on Android, Internet, YouTube, Blogger, Make money, How to and Technical tips and tricks tutorial, We also share Whatsapp Group Links, Whatsapp Status, Android Tips and Tricks and many more tech related posts.
<div class="footer-email-wrap">Contact us: <a href="/cdn-cgi/l/email-protection#8dcce9e0e4e3cdddffe2e0ecfef9e4a3eee2e0"><span class="__cf_email__" data-cfemail="f2b3969f9b9cb2a2809d9f9381869bdc919d9f">[email&#160;protected]</span></a></div></aside></div>        </div>
    </div>
</div>
</div>

<!-- Sub Footer -->
    <div class="td-sub-footer-container td-container-wrap ">
        <div class="td-container">
            <div class="td-pb-row">
                <div class="td-pb-span td-sub-footer-menu">
                        <div class="menu-top-menu-container"><ul id="menu-top-menu-1" class="td-subfooter-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-first td-menu-item td-normal-menu menu-item-539"><a href="http://www.promasti.com/about/">About</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-190"><a href="http://promasti.com/sitemap.xml">Sitemap</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-538"><a href="http://www.promasti.com/contact/">Contact Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-55"><a href="http://www.promasti.com/privacy-policy/">Privacy Policy</a></li>
</ul></div>                </div>

                <div class="td-pb-span td-sub-footer-copy">
                    &copy; All Right reserved 2018 <a href="http://ProMasti.Com/" rel="nofollow">ProMasti.Com</a>                </div>
            </div>
        </div>
    </div>
</div><!--close td-outer-wrap-->

<div style="text-align: center;"><a href="https://www.w3-edge.com/products/" rel="external">Optimization WordPress Plugins &amp; Solutions by W3 EDGE</a></div>	<div style="display:none">
	</div>


    <!--

        Theme: Newspaper by tagDiv.com 2017
        Version: 8.1 (rara)
        Deploy mode: deploy
        
        uid: 5b56ec6adbb09
    -->

    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/www.promasti.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="http://www.promasti.com/wp-content/cache/minify/0fef6.js"></script>

<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var tocplus = {"visibility_show":"show","visibility_hide":"hide","width":"Auto"};
/* ]]> */
</script>


<script type="text/javascript" src="http://www.promasti.com/wp-content/cache/minify/6f647.js"></script>


<!-- JS generated by theme -->

<script>
    

	

		(function(){
			var html_jquery_obj = jQuery('html');

			if (html_jquery_obj.length && (html_jquery_obj.is('.ie8') || html_jquery_obj.is('.ie9'))) {

				var path = 'http://www.promasti.com/wp-content/themes/Newspaper/style.css';

				jQuery.get(path, function(data) {

					var str_split_separator = '#td_css_split_separator';
					var arr_splits = data.split(str_split_separator);
					var arr_length = arr_splits.length;

					if (arr_length > 1) {

						var dir_path = 'http://www.promasti.com/wp-content/themes/Newspaper';
						var splited_css = '';

						for (var i = 0; i < arr_length; i++) {
							if (i > 0) {
								arr_splits[i] = str_split_separator + ' ' + arr_splits[i];
							}
							//jQuery('head').append('<style>' + arr_splits[i] + '</style>');

							var formated_str = arr_splits[i].replace(/\surl\(\'(?!data\:)/gi, function regex_function(str) {
								return ' url(\'' + dir_path + '/' + str.replace(/url\(\'/gi, '').replace(/^\s+|\s+$/gm,'');
							});

							splited_css += "<style>" + formated_str + "</style>";
						}

						var td_theme_css = jQuery('link#td-theme-css');

						if (td_theme_css.length) {
							td_theme_css.after(splited_css);
						}
					}
				});
			}
		})();

	
	
</script>

<script type='text/javascript' src='https://stats.wp.com/e-201830.js' async='async' defer='defer'></script>
<script type='text/javascript'>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:6.3.2',blog:'15584323',post:'0',tz:'-5.5',srv:'www.promasti.com'} ]);
	_stq.push([ 'clickTrackerInit', '15584323', '0' ]);
</script>


			<div id="tdw-css-writer" style="display: none" class="tdw-drag-dialog tdc-window-sidebar">
				<header>

				
					<a title="Editor" class="tdw-tab tdc-tab-active" href="#" data-tab-content="tdw-tab-editor">Edit with Live CSS</a>
					<div class="tdw-less-info" title="This will be red when errors are detected in your CSS and LESS"></div>
				
				</header>
				<div class="tdw-content">

					
					<div class="tdw-tabs-content tdw-tab-editor tdc-tab-content-active">


						<script>

							(function(jQuery, undefined) {

								jQuery(window).ready(function() {

									if ( 'undefined' !== typeof tdcAdminIFrameUI ) {
										var $liveIframe  = tdcAdminIFrameUI.getLiveIframe();

										if ( $liveIframe.length ) {
											$liveIframe.load(function() {
												$liveIframe.contents().find( 'body').append( '<textarea class="tdw-css-writer-editor" style="display: none"></textarea>' );
											});
										}
									}

								});

							})(jQuery);

						</script>


						<textarea class="tdw-css-writer-editor td_live_css_uid_1_5b56ec6adc3bb"></textarea>
						<div id="td_live_css_uid_1_5b56ec6adc3bb" class="td-code-editor"></div>


						<script>
							jQuery(window).load(function (){

								if ( 'undefined' !== typeof tdLiveCssInject ) {

									tdLiveCssInject.init();


									var editor_textarea = jQuery('.td_live_css_uid_1_5b56ec6adc3bb');
									var languageTools = ace.require("ace/ext/language_tools");
									var tdcCompleter = {
										getCompletions: function (editor, session, pos, prefix, callback) {
											if (prefix.length === 0) {
												callback(null, []);
												return
											}

											if ('undefined' !== typeof tdcAdminIFrameUI) {

												var data = {
													error: undefined,
													getShortcode: ''
												};

												tdcIFrameData.getShortcodeFromData(data);

												if (!_.isUndefined(data.error)) {
													tdcDebug.log(data.error);
												}

												if (!_.isUndefined(data.getShortcode)) {

													var regex = /el_class=\"([A-Za-z0-9_-]*\s*)+\"/g,
														results = data.getShortcode.match(regex);

													var elClasses = {};

													for (var i = 0; i < results.length; i++) {
														var currentClasses = results[i]
															.replace('el_class="', '')
															.replace('"', '')
															.split(' ');

														for (var j = 0; j < currentClasses.length; j++) {
															if (_.isUndefined(elClasses[currentClasses[j]])) {
																elClasses[currentClasses[j]] = '';
															}
														}
													}

													var arrElClasses = [];

													for (var prop in elClasses) {
														arrElClasses.push(prop);
													}

													callback(null, arrElClasses.map(function (item) {
														return {
															name: item,
															value: item,
															meta: 'in_page'
														}
													}));
												}
											}
										}
									};
									languageTools.addCompleter(tdcCompleter);

									window.editor = ace.edit("td_live_css_uid_1_5b56ec6adc3bb");

									// 'change' handler is written as function because it's called by tdc_on_add_css_live_components (of wp_footer hook)
									// We did it to reattach the existing compiled css to the new content received from server.
									window.editorChangeHandler = function () {
										//tdwState.lessWasEdited = true;

										window.onbeforeunload = function () {
											if (tdwState.lessWasEdited) {
												return "You have attempted to leave this page. Are you sure?";
											}
											return false;
										};

										var editorValue = editor.getSession().getValue();

										editor_textarea.val(editorValue);

										if ('undefined' !== typeof tdcAdminIFrameUI) {
											tdcAdminIFrameUI.getLiveIframe().contents().find('.tdw-css-writer-editor:first').val(editorValue);

											// Mark the content as modified
											// This is important for showing info when composer closes
                                            tdcMain.setContentModified();
										}

										tdLiveCssInject.less();
									};

									editor.getSession().setValue(editor_textarea.val());
									editor.getSession().on('change', editorChangeHandler);

									editor.setTheme("ace/theme/textmate");
									editor.setShowPrintMargin(false);
									editor.getSession().setMode("ace/mode/less");
									editor.setOptions({
										enableBasicAutocompletion: true,
										enableSnippets: true,
										enableLiveAutocompletion: false
									});

								}

							});
						</script>

					</div>
				</div>

				<footer>

					
						<a href="#" class="tdw-save-css">Save</a>
						<div class="tdw-more-info-text">Write CSS OR LESS and hit save. CTRL + SPACE for auto-complete.</div>

					
					<div class="tdw-resize"></div>
				</footer>
			</div>
			
</body>
</html>
<!--
Object Caching 79/219 objects using disk
Page Caching using disk: enhanced 
Minified using disk
Database Caching 3/45 queries in 0.212 seconds using disk (Request-wide modification query)

Served from: www.promasti.com @ 2018-07-24 03:37:55 by W3 Total Cache
-->